package com.chess.overlay;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChessService extends AccessibilityService {

    // ---- settings ----
    private SharedPreferences sp;
    private int depth = 8, delaySec = 3;
    private boolean autoMove = false, rating = true, showBest = false, showEnemy = false, showEval = false;

    // ---- infrastructure ----
    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private Engine engine;
    private View engineView;
    private float dp;

    // ---- overlay views ----
    private TextView bubble, status;
    private LinearLayout panel;
    private BadgeView badge;
    private ArrowView arrow;
    private EvalView evalBar;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private boolean panelOpen;
    private volatile int bubbleX, bubbleY;
    private volatile float[] badgeMask;
    private volatile ArrowShape arrowShape;
    private volatile boolean redetectFlag;
    private long arrowChangedAt;
    private int hideShots, bad, lastFailKey;
    private boolean menuOn = true;
    private SharedPreferences.OnSharedPreferenceChangeListener prefL;

    // ---- game tracking ----
    private volatile Vision vis = new Vision();
    private boolean shotBusy;
    private int frame;
    private Pos pos;
    private boolean flipped;
    private int[] prevScr;
    private int gen;
    private int analyzedGen = -1;
    private int prevCp;
    private String prevBest;
    private String lastPkg;
    private boolean running;

    // ======================================================================
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sp = getSharedPreferences("prefs", MODE_PRIVATE);
        depth = sp.getInt("depth", 8);
        delaySec = sp.getInt("delay", 3);
        autoMove = sp.getBoolean("auto", false);
        rating = sp.getBoolean("rating", true);
        showBest = sp.getBoolean("showBest", false);
        showEnemy = sp.getBoolean("showEnemy", false);
        showEval = sp.getBoolean("showEval", false);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        dp = getResources().getDisplayMetrics().density;
        engine = new Engine(this);
        menuOn = sp.getBoolean("menu", true);
        buildOverlays();
        applyMenu();
        prefL = (p, key) -> {
            if ("menu".equals(key)) { menuOn = p.getBoolean("menu", true); applyMenu(); }
        };
        sp.registerOnSharedPreferenceChangeListener(prefL);
        running = true;
        h.postDelayed(tick, 800);
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        running = false;
        if (sp != null && prefL != null) sp.unregisterOnSharedPreferenceChangeListener(prefL);
        h.removeCallbacksAndMessages(null);
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (panelOpen) wm.removeView(panel); } catch (Exception ignored) {}
        try { if (badge != null) wm.removeView(badge); } catch (Exception ignored) {}
        try { if (arrow != null) wm.removeView(arrow); } catch (Exception ignored) {}
        try { if (evalBar != null) wm.removeView(evalBar); } catch (Exception ignored) {}
        stopEngine();
        exec.shutdownNow();
        return super.onUnbind(intent);
    }

    @Override public void onInterrupt() {}

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
        String p = e.getPackageName().toString();
        if (p.equals(getPackageName()) || p.equals("com.android.systemui") || p.contains("inputmethod") || p.contains("keyboard")) return;
        lastPkg = p;
        redetectFlag = true;
    }

    // ======================================================================
    // Main loop: screenshot -> board -> move tracking
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { doTick(); } catch (Throwable t) { setStatus("Error: " + t); }
            h.postDelayed(this, 450);
        }
    };

    private boolean isChess() {
        String p = null;
        try {
            AccessibilityNodeInfo n = getRootInActiveWindow();
            if (n != null && n.getPackageName() != null) p = n.getPackageName().toString();
        } catch (Exception ignored) {}
        if (p == null) p = lastPkg;
        return p != null && p.startsWith("com.chess");
    }

    private void doTick() {
        if (!menuOn) return;
        if (!engineNeeded()) { setStatus("Idle (all features are off)"); return; }
        if (panelOpen) return;
        if (!isChess()) { badge.clear(); clearArrow(); evalBar.clear(); setStatus("Open a chess.com game"); return; }
        if (shotBusy) return;
        // let the overlay settle after the arrow appeared or disappeared
        if (System.currentTimeMillis() - arrowChangedAt < 250) return;
        shotBusy = true;
        // fallback only: if the position got lost while an arrow was on screen, hide it for a few shots
        final boolean hid = hideShots > 0 && arrow != null && arrow.active();
        if (hid) { hideShots--; arrow.setVisibility(View.INVISIBLE); }
        h.postDelayed(() -> shoot(hid), hid ? 90 : 0);
    }

    private void shoot(final boolean hid) {
        final ArrowShape as = hid ? null : arrowShape;
        final Runnable restore = () -> { if (hid && arrow != null) arrow.setVisibility(View.VISIBLE); };
        takeScreenshot(Display.DEFAULT_DISPLAY, exec, new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                h.post(restore);
                int[] scr = null;
                try {
                    HardwareBuffer hb = r.getHardwareBuffer();
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    Bitmap bmp = hw.copy(Bitmap.Config.ARGB_8888, false);
                    hw.recycle();
                    hb.close();
                    scr = scan(bmp, as);
                    bmp.recycle();
                } catch (Throwable t) {
                    final String m = String.valueOf(t);
                    h.post(() -> setStatus("Screenshot error: " + m));
                }
                final int[] fs = scr;
                h.post(() -> { shotBusy = false; onObserved(fs); });
            }
            @Override public void onFailure(int code) {
                h.post(restore);
                h.post(() -> { shotBusy = false; setStatus("Screenshot failed (code " + code + ")"); });
            }
        });
    }

    /** Runs on the executor thread. */
    private int[] scan(Bitmap bmp, ArrowShape as) {
        int w = bmp.getWidth(), hh = bmp.getHeight();
        Vision v = vis;
        boolean redetect = !v.ok || redetectFlag || (++frame % 25 == 0);
        if (!redetect) {
            int bx = (int) v.x0, by = (int) v.y0, bs = (int) Math.ceil(v.s * 8);
            if (bx < 0 || by < 0 || bx + bs > w || by + bs > hh) redetect = true;
            else {
                int[] px = new int[bs * bs];
                bmp.getPixels(px, 0, bs, bx, by, bs, bs);
                // the board is not where we think it is, or something (dialog, menu) covers it: look again, do not guess
                if (v.boardScore(px, bs, bx, by) < 40) { redetectFlag = true; return null; }
                return v.classify(px, bs, bx, by, masks(), as);
            }
        }
        redetectFlag = false;
        int[] px = new int[w * hh];
        bmp.getPixels(px, 0, w, 0, 0, w, hh);
        Vision nv = new Vision();
        if (!nv.detect(px, w, hh)) { vis = new Vision(); return null; }
        vis = nv;
        return nv.classify(px, w, 0, 0, masks(), as);
    }

    private float[] masks() {
        float[] bm = badgeMask;
        float r = 26 * dp;
        float cx = bubbleX + 22 * dp, cy = bubbleY + 22 * dp;
        if (bm == null) return new float[]{cx, cy, r};
        return new float[]{cx, cy, r, bm[0], bm[1], bm[2]};
    }

    private void onObserved(int[] scr) {
        if (scr == null) { setStatus("Green chess.com board not found"); return; }
        for (int i = 0; i < 64; i++) if (scr[i] < 0) scr[i] = prevScr != null ? Math.max(prevScr[i], 0) : 0;
        if (!Arrays.equals(scr, prevScr)) { prevScr = scr.clone(); return; } // wait until stable for two samples
        int ori = Pos.startOrientation(scr);
        if (ori != 0 && (pos == null || pos.plies > 0 || flipped != (ori == 2))) { newGame(ori == 2); return; }
        if (pos == null) { recoverFromStart(scr); return; }
        int[] board = Pos.toBoard(scr, flipped);
        int r = pos.observe(board);
        if (r == 0) { bad = 0; return; }
        if (r == 1) { bad = 0; onMove(); return; }
        // The board moved on by more than one ply (menu was open, a move was missed ...): catch up.
        int key = Arrays.hashCode(scr);
        if (key != lastFailKey) {
            Pos t = pos.catchUp(board, 6);
            if (t != null) { bad = 0; pos = t; resumeAfterJump(); return; }
            lastFailKey = key;
        }
        if (arrow != null && arrow.active()) hideShots = 3;
        redetectFlag = true;
        if (++bad >= 3 && recoverFromStart(scr)) { bad = 0; return; }
        setStatus("Position not recognised. It will resync by itself, or start a new game.");
    }

    /** Rebuilds the game from the start position when only a few plies have been played (e.g. the first moves were missed). */
    private boolean recoverFromStart(int[] scr) {
        int key = Arrays.hashCode(scr);
        if (key != lastFailKey) {
            for (int k = 0; k < 2; k++) {
                boolean fl = k == 0 ? flipped : !flipped;
                Pos t = Pos.start().catchUp(Pos.toBoard(scr, fl), 6);
                if (t != null) { pos = t; flipped = fl; bad = 0; resumeAfterJump(); return true; }
            }
            lastFailKey = key;
        }
        if (pos == null) setStatus("Waiting for a new game (start position)");
        return false;
    }

    private void resumeAfterJump() {
        gen++;
        analyzedGen = -1;
        badge.clear();
        badgeMask = null;
        clearArrow();
        setStatus("Tracking. You play " + (flipped ? "Black" : "White") + ". Move " + pos.full + ", " + (pos.white ? "White" : "Black") + " to move");
        requestAnalysis(null);
    }

    private void newGame(boolean blackAtBottom) {
        pos = Pos.start();
        flipped = blackAtBottom;
        bad = 0;
        lastFailKey = 0;
        evalBar.clear();
        gen++;
        analyzedGen = -1;
        badge.clear();
        badgeMask = null;
        clearArrow();
        setStatus("Tracking. You play " + (flipped ? "Black" : "White"));
        requestAnalysis(null);
    }

    private void onMove() {
        gen++;
        clearArrow();
        setStatus("Move " + pos.full + ", " + (pos.white ? "White" : "Black") + " to move");
        requestAnalysis(pos.last);
    }

    private boolean myTurn() { return pos != null && pos.white == !flipped; }

    private void requestAnalysis(final Pos.Mv made) {
        if (engine == null || !engine.isRunning() || pos == null) return;
        if (!rating && !showEval && !(myTurn() ? (showBest || autoMove) : showEnemy)) return;
        final int g = gen;
        final String fen = pos.fen();
        final long t0 = System.currentTimeMillis();
        engine.request(fen, depth, (cp, best) -> {
            if (g != gen || pos == null) return;
            if (made != null && rating && analyzedGen == g - 1) rateMove(made, prevCp + cp, prevBest);
            analyzedGen = g;
            prevCp = cp;
            prevBest = best;
            updateEval(cp);
            updateArrow(best);
            if (autoMove && best != null && myTurn()) {
                long wait = Math.max(0, t0 + delaySec * 1000L - System.currentTimeMillis());
                h.postDelayed(() -> {
                    if (g == gen && autoMove && myTurn() && !panelOpen && isChess()) playMove(best);
                }, wait);
            }
        });
    }

    // ======================================================================
    // Best-move arrow (green = my best move, orange = enemy best move)
    private boolean engineNeeded() { return autoMove || rating || showBest || showEnemy || showEval; }

    private void updateArrow(String best) {
        boolean mine = myTurn();
        if (best == null || best.length() < 4 || !(mine ? showBest : showEnemy)) { clearArrow(); return; }
        Vision v = vis;
        if (!v.ok) { clearArrow(); return; }
        float[] a = center(Pos.idx(best, 0), v), b = center(Pos.idx(best, 2), v);
        // blue = my best move, orange = enemy best move; semi-transparent so its tint can be removed from screenshots exactly
        ArrowShape shape = new ArrowShape(a[0], a[1], b[0], b[1], 0.14f * v.s, mine ? 0x8C1E88E5 : 0x8CE58F2A);
        arrowShape = shape;
        arrowChangedAt = System.currentTimeMillis();
        arrow.show(shape);
    }

    /** cp is from the side to move; the bar shows it from White's point of view. */
    private void updateEval(int cp) {
        if (!showEval) { evalBar.clear(); return; }
        Vision v = vis;
        if (!v.ok) return;
        int white = pos.white ? cp : -cp;
        float h = 16 * dp;
        evalBar.show(v.x0, v.y0 - h - 4 * dp, 8 * v.s, h, white);
    }

    private void clearArrow() {
        if (arrowShape != null) arrowChangedAt = System.currentTimeMillis();
        arrowShape = null;
        if (arrow != null) arrow.clear();
    }

    // ======================================================================
    // Move rating badge
    private void rateMove(Pos.Mv m, int loss, String best) {
        String t; int col;
        boolean isBest = best != null && best.length() >= 4 && best.substring(0, 4).equals(m.uci());
        if (isBest || loss <= 5) { t = "\u2605"; col = 0xFF81B64C; }
        else if (loss <= 25) { t = "!"; col = 0xFF96BC4B; }
        else if (loss <= 60) { t = "\u2713"; col = 0xFF95B776; }
        else if (loss <= 120) { t = "?!"; col = 0xFFF7C631; }
        else if (loss <= 250) { t = "?"; col = 0xFFE58F2A; }
        else { t = "??"; col = 0xFFCA3431; }
        Vision v = vis;
        int si = Pos.toScreen(m.to, flipped);
        float cx = v.x0 + (si % 8 + 1) * v.s - 0.2f * v.s;
        float cy = v.y0 + (si / 8) * v.s + 0.2f * v.s;
        float r = 0.2f * v.s;
        badgeMask = new float[]{cx, cy, r + 4 * dp};
        badge.show(cx, cy, r, t, col);
    }

    // ======================================================================
    // Executing a move by tapping
    private void playMove(String uci) {
        Vision v = vis;
        if (!v.ok || uci.length() < 4) return;
        final float[] a = center(Pos.idx(uci, 0), v), b = center(Pos.idx(uci, 2), v);
        setStatus("Playing " + uci);
        tap(a[0], a[1]);
        h.postDelayed(() -> tap(b[0], b[1]), 350);
        if (uci.length() > 4) h.postDelayed(() -> tap(b[0], b[1]), 1100); // promotion: pick the queen
    }

    private float[] center(int boardIdx, Vision v) {
        int si = Pos.toScreen(boardIdx, flipped);
        return new float[]{v.x0 + (si % 8 + 0.5f) * v.s, v.y0 + (si / 8 + 0.5f) * v.s};
    }

    private void tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 50)).build();
        dispatchGesture(g, null, null);
    }

    // ======================================================================
    // Engine lifecycle
    private void syncEngine() {
        boolean need = engineNeeded();
        if (need && !engine.isRunning()) {
            engineView = engine.start();
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            try { wm.addView(engineView, lp); } catch (Exception ignored) {}
            if (pos != null) requestAnalysis(null);
        } else if (!need && engine.isRunning()) {
            stopEngine();
        }
    }

    private void stopEngine() {
        try { if (engineView != null) wm.removeView(engineView); } catch (Exception ignored) {}
        engineView = null;
        if (engine != null) engine.stop();
        analyzedGen = -1;
    }

    // ======================================================================
    // UI
    private void setStatus(String s) { if (status != null) status.setText(s); }

    private int px(int v) { return (int) (v * dp); }

    private void buildOverlays() {
        // rating badge layer (touch-through, full screen)
        badge = new BadgeView(this);
        WindowManager.LayoutParams bl = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bl.gravity = Gravity.TOP | Gravity.START;
        bl.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(badge, bl);

        // best-move arrow layer (touch-through, full screen)
        arrow = new ArrowView(this);
        WindowManager.LayoutParams al = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        al.gravity = Gravity.TOP | Gravity.START;
        al.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(arrow, al);

        // evaluation bar layer (touch-through, full screen)
        evalBar = new EvalView(this);
        WindowManager.LayoutParams el = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        el.gravity = Gravity.TOP | Gravity.START;
        el.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(evalBar, el);

        // floating bubble
        bubble = new TextView(this);
        bubble.setText("\u265E");
        bubble.setTextSize(22);
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xFF769656);
        bubble.setBackground(bg);
        bubbleLp = new WindowManager.LayoutParams(px(44), px(44),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = sp.getInt("bx", 0);
        bubbleLp.y = sp.getInt("by", px(110));
        bubbleX = bubbleLp.x;
        bubbleY = bubbleLp.y;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = bubbleLp.x; sy = bubbleLp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > 12 || Math.abs(e.getRawY() - dy) > 12) moved = true;
                        if (moved) {
                            bubbleLp.x = sx + (int) (e.getRawX() - dx);
                            bubbleLp.y = sy + (int) (e.getRawY() - dy);
                            bubbleX = bubbleLp.x; bubbleY = bubbleLp.y;
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) sp.edit().putInt("bx", bubbleLp.x).putInt("by", bubbleLp.y).apply();
                        else togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);

        buildPanel();
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(px(16), px(14), px(16), px(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF262522);
        bg.setCornerRadius(px(14));
        panel.setBackground(bg);

        TextView title = label("Chess Assistant", 17, true);
        panel.addView(title);

        final TextView dl = label("Stockfish Deep: " + depth, 14, false);
        panel.addView(dl);
        SeekBar sd = new SeekBar(this);
        sd.setMax(14);
        sd.setProgress(depth - 1);
        sd.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                depth = p + 1;
                dl.setText("Stockfish Deep: " + depth);
                sp.edit().putInt("depth", depth).apply();
            }
        });
        panel.addView(sd);

        final Switch sa = new Switch(this);
        sa.setText("Auto move");
        sa.setTextColor(Color.WHITE);
        sa.setChecked(autoMove);
        sa.setOnCheckedChangeListener((b, on) -> {
            autoMove = on;
            sp.edit().putBoolean("auto", on).apply();
            syncEngine();
        });
        panel.addView(sa);

        final TextView ll = label("Auto move delay: " + delaySec + " s", 14, false);
        panel.addView(ll);
        SeekBar sl = new SeekBar(this);
        sl.setMax(19);
        sl.setProgress(delaySec - 1);
        sl.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                delaySec = p + 1;
                ll.setText("Auto move delay: " + delaySec + " s");
                sp.edit().putInt("delay", delaySec).apply();
            }
        });
        panel.addView(sl);

        final Switch sr = new Switch(this);
        sr.setText("Move rating");
        sr.setTextColor(Color.WHITE);
        sr.setChecked(rating);
        sr.setOnCheckedChangeListener((b, on) -> {
            rating = on;
            sp.edit().putBoolean("rating", on).apply();
            if (!on) { badge.clear(); badgeMask = null; }
            syncEngine();
        });
        panel.addView(sr);

        final Switch sb = new Switch(this);
        sb.setText("Show best move");
        sb.setTextColor(Color.WHITE);
        sb.setChecked(showBest);
        sb.setOnCheckedChangeListener((b, on) -> {
            showBest = on;
            sp.edit().putBoolean("showBest", on).apply();
            clearArrow();
            syncEngine();
            if (on && pos != null && engine.isRunning()) requestAnalysis(null);
        });
        panel.addView(sb);

        final Switch se = new Switch(this);
        se.setText("Show enemy best move");
        se.setTextColor(Color.WHITE);
        se.setChecked(showEnemy);
        se.setOnCheckedChangeListener((b, on) -> {
            showEnemy = on;
            sp.edit().putBoolean("showEnemy", on).apply();
            clearArrow();
            syncEngine();
            if (on && pos != null && engine.isRunning()) requestAnalysis(null);
        });
        panel.addView(se);

        final Switch sv = new Switch(this);
        sv.setText("Evaluation bar");
        sv.setTextColor(Color.WHITE);
        sv.setChecked(showEval);
        sv.setOnCheckedChangeListener((b, on) -> {
            showEval = on;
            sp.edit().putBoolean("showEval", on).apply();
            if (!on) evalBar.clear();
            syncEngine();
            if (on && pos != null && engine.isRunning()) requestAnalysis(null);
        });
        panel.addView(sv);

        status = label("", 12, false);
        status.setTextColor(0xFFAAAAAA);
        status.setPadding(0, px(10), 0, 0);
        panel.addView(status);

        panelLp = new WindowManager.LayoutParams(px(300), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelLp.y = px(70);
    }

    private TextView label(String t, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(size);
        v.setTextColor(Color.WHITE);
        v.setPadding(0, px(6), 0, 0);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    /** Menu on = bubble, panel and overlays are active. Menu off = everything hidden and the engine stopped. */
    private void applyMenu() {
        if (bubble == null) return;
        if (menuOn) {
            bubble.setVisibility(View.VISIBLE);
            syncEngine();
        } else {
            if (panelOpen) togglePanel();
            bubble.setVisibility(View.GONE);
            badge.clear();
            badgeMask = null;
            clearArrow();
            evalBar.clear();
            stopEngine();
            pos = null;
            prevScr = null;
        }
    }

    private void togglePanel() {
        redetectFlag = true;
        try {
            if (panelOpen) { wm.removeView(panel); panelOpen = false; }
            else { wm.addView(panel, panelLp); panelOpen = true; }
        } catch (Exception ignored) {}
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        abstract void changed(int p);
        @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) changed(p); }
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }

    /** Draws one arrow on top of the game. Touch-through. */
    static final class ArrowView extends View {
        private ArrowShape shape;
        private boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        ArrowView(Context c) { super(c); }

        void show(ArrowShape s) {
            shape = s;
            Path q = new Path(), t = new Path();
            q.moveTo(s.quad[0], s.quad[1]); q.lineTo(s.quad[2], s.quad[3]);
            q.lineTo(s.quad[4], s.quad[5]); q.lineTo(s.quad[6], s.quad[7]); q.close();
            t.moveTo(s.tri[0], s.tri[1]); t.lineTo(s.tri[2], s.tri[3]); t.lineTo(s.tri[4], s.tri[5]); t.close();
            path.reset();
            if (!path.op(q, t, Path.Op.UNION)) { path.reset(); path.addPath(q); path.addPath(t); }
            on = true;
            invalidate();
        }

        void clear() {
            if (on) { on = false; shape = null; invalidate(); }
        }

        boolean active() { return on; }

        @Override protected void onDraw(Canvas c) {
            if (!on || shape == null) return;
            p.setStyle(Paint.Style.FILL);
            p.setColor(shape.argb);
            c.drawPath(path, p);   // one draw call: the shaft and the head never double-blend
        }
    }

    /** Horizontal evaluation bar (White left, Black right) drawn above the board. Touch-through. */
    static final class EvalView extends View {
        private float x, y, w, h;
        private int cp;
        private boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.RectF rect = new android.graphics.RectF();

        EvalView(Context c) { super(c); }

        void show(float left, float top, float width, float height, int whiteCp) {
            x = left; y = top; w = width; h = height; cp = whiteCp; on = true;
            invalidate();
        }

        void clear() {
            if (on) { on = false; invalidate(); }
        }

        @Override protected void onDraw(Canvas c) {
            if (!on) return;
            float frac = (float) (1.0 / (1.0 + Math.exp(-0.00368 * cp)));
            float r = h / 2f;
            rect.set(x, y, x + w, y + h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF403E3B);
            c.drawRoundRect(rect, r, r, p);
            c.save();
            android.graphics.Path clip = new android.graphics.Path();
            clip.addRoundRect(rect, r, r, android.graphics.Path.Direction.CW);
            c.clipPath(clip);
            p.setColor(0xFFFFFFFF);
            c.drawRect(x, y, x + w * frac, y + h, p);
            c.restore();
            String t = Math.abs(cp) >= 1000 ? (cp > 0 ? "+10+" : "-10+")
                    : String.format(java.util.Locale.US, "%+.2f", cp / 100f);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(h * 0.7f);
            float ty = y + h / 2f - (p.descent() + p.ascent()) / 2f;
            float pad = h * 0.5f;
            if (cp >= 0) { p.setTextAlign(Paint.Align.LEFT); p.setColor(0xFF403E3B); c.drawText(t, x + pad, ty, p); }
            else { p.setTextAlign(Paint.Align.RIGHT); p.setColor(0xFFFFFFFF); c.drawText(t, x + w - pad, ty, p); }
        }
    }

    /** Draws one rating badge on top of the game. Touch-through. */
    static final class BadgeView extends View {
        private float cx, cy, r;
        private String text;
        private int color;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        BadgeView(Context c) { super(c); }

        void show(float x, float y, float rad, String t, int col) {
            cx = x; cy = y; r = rad; text = t; color = col;
            invalidate();
        }

        void clear() {
            if (text != null) { text = null; invalidate(); }
        }

        @Override protected void onDraw(Canvas c) {
            if (text == null) return;
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(r * 0.12f);
            p.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(r * (text.length() > 1 ? 1.0f : 1.25f));
            c.drawText(text, cx, cy - (p.descent() + p.ascent()) / 2f, p);
        }
    }
}
