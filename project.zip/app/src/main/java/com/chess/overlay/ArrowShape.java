package com.chess.overlay;

/**
 * Geometry and colour of the best-move arrow. Shared by the drawing code and by the board recognition,
 * which removes the arrow's tint from the screenshot so the arrow never disturbs piece detection.
 */
final class ArrowShape {
    final float x1, y1, x2, y2, w;
    final int argb;
    final float k;           // arrow opacity 0..1
    final float ux, uy, nx, ny, tEnd;
    final float[] quad, tri;

    ArrowShape(float x1, float y1, float x2, float y2, float w, int argb) {
        this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; this.w = w; this.argb = argb;
        this.k = ((argb >>> 24) & 255) / 255f;
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.hypot(dx, dy);
        if (len < 1f) len = 1f;
        ux = dx / len; uy = dy / len; nx = -uy; ny = ux;
        float head = Math.min(w * 2.6f, len * 0.6f);
        float bx = x2 - ux * head, by = y2 - uy * head;           // base of the head
        float ext = Math.min(w * 0.8f, head * 0.5f);              // the shaft reaches a bit into the head
        float ex = bx + ux * ext, ey = by + uy * ext;
        tEnd = (ex - x1) * ux + (ey - y1) * uy;
        float hw = w / 2f;
        quad = new float[]{x1 + nx * hw, y1 + ny * hw, ex + nx * hw, ey + ny * hw,
                ex - nx * hw, ey - ny * hw, x1 - nx * hw, y1 - ny * hw};
        tri = new float[]{x2, y2, bx + nx * w * 1.3f, by + ny * w * 1.3f, bx - nx * w * 1.3f, by - ny * w * 1.3f};
    }

    private float triSd(float x, float y) {
        float cx = (tri[0] + tri[2] + tri[4]) / 3f, cy = (tri[1] + tri[3] + tri[5]) / 3f;
        float best = -1e9f;
        for (int i = 0; i < 3; i++) {
            float px = tri[2 * i], py = tri[2 * i + 1];
            float qx = tri[2 * ((i + 1) % 3)], qy = tri[2 * ((i + 1) % 3) + 1];
            float ex = qx - px, ey = qy - py;
            float l = (float) Math.hypot(ex, ey);
            if (l < 1e-3f) continue;
            float a = ey / l, b = -ex / l;
            if ((cx - px) * a + (cy - py) * b > 0) { a = -a; b = -b; }
            best = Math.max(best, (x - px) * a + (y - py) * b);
        }
        return best;
    }

    /** 0 = outside the arrow, 1 = safely inside, 2 = on the anti-aliased edge (do not trust the pixel). */
    int cover(float x, float y) {
        float px = x - x1, py = y - y1;
        float t = px * ux + py * uy, v = px * nx + py * ny;
        float sdBox = Math.max(Math.abs(v) - w / 2f, Math.max(-t, t - tEnd));
        float sd = Math.min(sdBox, triSd(x, y));
        final float tol = 1.6f;
        if (sd > tol) return 0;
        if (sd < -tol) return 1;
        return 2;
    }

    private int ch(int v, int c) {
        int o = Math.round((v - k * c) / (1f - k));
        return o < 0 ? 0 : Math.min(255, o);
    }

    /** Returns the pixel as it would look without the arrow. */
    int unblend(int p) {
        int r = ch((p >> 16) & 255, (argb >> 16) & 255);
        int g = ch((p >> 8) & 255, (argb >> 8) & 255);
        int b = ch(p & 255, argb & 255);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
