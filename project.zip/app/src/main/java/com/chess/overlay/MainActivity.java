package com.chess.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView state;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (22 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Chess Assistant");
        title.setTextSize(22);
        root.addView(title);

        state = new TextView(this);
        state.setTextSize(16);
        state.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(state);

        TextView help = new TextView(this);
        help.setTextSize(14);
        help.setText("1. Tap \"Open accessibility settings\", find Chess Assistant and turn it on.\n"
                + "   Android 13+: if the switch is greyed out, tap \"Open app info\", open the \u22EE menu and choose \"Allow restricted settings\", then try again.\n\n"
                + "2. Open a chess.com game (green board). A round bubble appears on screen: tap it for the settings, drag it to move it. Keep it off the board.\n\n"
                + "3. The service tracks the game from the start position, so start a new game while it is on.\n\n"
                + "Use Auto move only in games against the computer.");
        root.addView(help);

        Button a = new Button(this);
        a.setText("Open accessibility settings");
        a.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(a);

        Button i = new Button(this);
        i.setText("Open app info");
        i.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        root.addView(i);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean on = enabled != null && enabled.contains(getPackageName() + "/");
        state.setText(on ? "Accessibility service: ON" : "Accessibility service: OFF");
        state.setTextColor(on ? 0xFF2E7D32 : 0xFFC62828);
    }
}
