package com.chess.overlay;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChessService extends AccessibilityService {

    // ---- settings ----
    private SharedPreferences sp;
    private int depth = 8, delaySec = 3;
    private boolean autoMove = false, rating = true;

    // ---- infrastructure ----
    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private Engine engine;
    private View engineView;
    private float dp;

    // ---- overlay views ----
    private TextView bubble, status;
    private LinearLayout panel;
    private BadgeView badge;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private boolean panelOpen;
    private volatile int bubbleX, bubbleY;
    private volatile float[] badgeMask;

    // ---- game tracking ----
    private volatile Vision vis = new Vision();
    private boolean shotBusy;
    private int frame;
    private Pos pos;
    private boolean flipped;
    private int[] prevScr;
    private int gen;
    private int analyzedGen = -1;
    private int prevCp;
    private String prevBest;
    private String lastPkg;
    private boolean running;

    // ======================================================================
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sp = getSharedPreferences("prefs", MODE_PRIVATE);
        depth = sp.getInt("depth", 8);
        delaySec = sp.getInt("delay", 3);
        autoMove = sp.getBoolean("auto", false);
        rating = sp.getBoolean("rating", true);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        dp = getResources().getDisplayMetrics().density;
        engine = new Engine(this);
        buildOverlays();
        syncEngine();
        running = true;
        h.postDelayed(tick, 800);
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        running = false;
        h.removeCallbacksAndMessages(null);
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (panelOpen) wm.removeView(panel); } catch (Exception ignored) {}
        try { if (badge != null) wm.removeView(badge); } catch (Exception ignored) {}
        stopEngine();
        exec.shutdownNow();
        return super.onUnbind(intent);
    }

    @Override public void onInterrupt() {}

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
        String p = e.getPackageName().toString();
        if (p.equals(getPackageName()) || p.equals("com.android.systemui") || p.contains("inputmethod") || p.contains("keyboard")) return;
        lastPkg = p;
    }

    // ======================================================================
    // Main loop: screenshot -> board -> move tracking
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { doTick(); } catch (Throwable t) { setStatus("Error: " + t); }
            h.postDelayed(this, 450);
        }
    };

    private boolean isChess() {
        String p = null;
        try {
            AccessibilityNodeInfo n = getRootInActiveWindow();
            if (n != null && n.getPackageName() != null) p = n.getPackageName().toString();
        } catch (Exception ignored) {}
        if (p == null) p = lastPkg;
        return p != null && p.startsWith("com.chess");
    }

    private void doTick() {
        if (!autoMove && !rating) { setStatus("Idle (Auto move and Move rating are off)"); return; }
        if (panelOpen) return;
        if (!isChess()) { badge.clear(); setStatus("Open a chess.com game"); return; }
        if (shotBusy) return;
        shotBusy = true;
        takeScreenshot(Display.DEFAULT_DISPLAY, exec, new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                int[] scr = null;
                try {
                    HardwareBuffer hb = r.getHardwareBuffer();
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    Bitmap bmp = hw.copy(Bitmap.Config.ARGB_8888, false);
                    hw.recycle();
                    hb.close();
                    scr = scan(bmp);
                    bmp.recycle();
                } catch (Throwable t) {
                    final String m = String.valueOf(t);
                    h.post(() -> setStatus("Screenshot error: " + m));
                }
                final int[] fs = scr;
                h.post(() -> { shotBusy = false; onObserved(fs); });
            }
            @Override public void onFailure(int code) {
                h.post(() -> { shotBusy = false; setStatus("Screenshot failed (code " + code + ")"); });
            }
        });
    }

    /** Runs on the executor thread. */
    private int[] scan(Bitmap bmp) {
        int w = bmp.getWidth(), hh = bmp.getHeight();
        Vision v = vis;
        boolean redetect = !v.ok || (++frame % 25 == 0);
        if (!redetect) {
            int bx = (int) v.x0, by = (int) v.y0, bs = (int) Math.ceil(v.s * 8);
            if (bx < 0 || by < 0 || bx + bs > w || by + bs > hh) redetect = true;
            else {
                int[] px = new int[bs * bs];
                bmp.getPixels(px, 0, bs, bx, by, bs, bs);
                return v.classify(px, bs, bx, by, masks());
            }
        }
        int[] px = new int[w * hh];
        bmp.getPixels(px, 0, w, 0, 0, w, hh);
        Vision nv = new Vision();
        if (!nv.detect(px, w, hh)) { vis = new Vision(); return null; }
        vis = nv;
        return nv.classify(px, w, 0, 0, masks());
    }

    private float[] masks() {
        float[] bm = badgeMask;
        float r = 26 * dp;
        float cx = bubbleX + 22 * dp, cy = bubbleY + 22 * dp;
        if (bm == null) return new float[]{cx, cy, r};
        return new float[]{cx, cy, r, bm[0], bm[1], bm[2]};
    }

    private void onObserved(int[] scr) {
        if (scr == null) { setStatus("Green chess.com board not found"); return; }
        for (int i = 0; i < 64; i++) if (scr[i] < 0) scr[i] = prevScr != null ? Math.max(prevScr[i], 0) : 0;
        if (!Arrays.equals(scr, prevScr)) { prevScr = scr.clone(); return; } // wait until stable for two samples
        int ori = Pos.startOrientation(scr);
        if (ori != 0 && (pos == null || pos.plies > 0 || flipped != (ori == 2))) newGame(ori == 2);
        if (pos == null) { setStatus("Waiting for a new game (start position)"); return; }
        int r = pos.observe(Pos.toBoard(scr, flipped));
        if (r == 1) onMove();
        else if (r == 2) setStatus("Position not recognised. Start a new game to resync.");
    }

    private void newGame(boolean blackAtBottom) {
        pos = Pos.start();
        flipped = blackAtBottom;
        gen++;
        analyzedGen = -1;
        badge.clear();
        badgeMask = null;
        setStatus("Tracking. You play " + (flipped ? "Black" : "White"));
        requestAnalysis(null);
    }

    private void onMove() {
        gen++;
        setStatus("Move " + pos.full + ", " + (pos.white ? "White" : "Black") + " to move");
        requestAnalysis(pos.last);
    }

    private boolean myTurn() { return pos != null && pos.white == !flipped; }

    private void requestAnalysis(final Pos.Mv made) {
        if (engine == null || !engine.isRunning() || pos == null) return;
        if (!rating && !myTurn()) return;
        final int g = gen;
        final String fen = pos.fen();
        final long t0 = System.currentTimeMillis();
        engine.request(fen, depth, (cp, best) -> {
            if (g != gen || pos == null) return;
            if (made != null && rating && analyzedGen == g - 1) rateMove(made, prevCp + cp, prevBest);
            analyzedGen = g;
            prevCp = cp;
            prevBest = best;
            if (autoMove && best != null && myTurn()) {
                long wait = Math.max(0, t0 + delaySec * 1000L - System.currentTimeMillis());
                h.postDelayed(() -> {
                    if (g == gen && autoMove && myTurn() && !panelOpen && isChess()) playMove(best);
                }, wait);
            }
        });
    }

    // ======================================================================
    // Move rating badge
    private void rateMove(Pos.Mv m, int loss, String best) {
        String t; int col;
        boolean isBest = best != null && best.length() >= 4 && best.substring(0, 4).equals(m.uci());
        if (isBest || loss <= 5) { t = "\u2605"; col = 0xFF81B64C; }
        else if (loss <= 25) { t = "!"; col = 0xFF96BC4B; }
        else if (loss <= 60) { t = "\u2713"; col = 0xFF95B776; }
        else if (loss <= 120) { t = "?!"; col = 0xFFF7C631; }
        else if (loss <= 250) { t = "?"; col = 0xFFE58F2A; }
        else { t = "??"; col = 0xFFCA3431; }
        Vision v = vis;
        int si = Pos.toScreen(m.to, flipped);
        float cx = v.x0 + (si % 8 + 1) * v.s - 0.2f * v.s;
        float cy = v.y0 + (si / 8) * v.s + 0.2f * v.s;
        float r = 0.2f * v.s;
        badgeMask = new float[]{cx, cy, r + 4 * dp};
        badge.show(cx, cy, r, t, col);
    }

    // ======================================================================
    // Executing a move by tapping
    private void playMove(String uci) {
        Vision v = vis;
        if (!v.ok || uci.length() < 4) return;
        final float[] a = center(Pos.idx(uci, 0), v), b = center(Pos.idx(uci, 2), v);
        setStatus("Playing " + uci);
        tap(a[0], a[1]);
        h.postDelayed(() -> tap(b[0], b[1]), 350);
        if (uci.length() > 4) h.postDelayed(() -> tap(b[0], b[1]), 1100); // promotion: pick the queen
    }

    private float[] center(int boardIdx, Vision v) {
        int si = Pos.toScreen(boardIdx, flipped);
        return new float[]{v.x0 + (si % 8 + 0.5f) * v.s, v.y0 + (si / 8 + 0.5f) * v.s};
    }

    private void tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 50)).build();
        dispatchGesture(g, null, null);
    }

    // ======================================================================
    // Engine lifecycle
    private void syncEngine() {
        boolean need = autoMove || rating;
        if (need && !engine.isRunning()) {
            engineView = engine.start();
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            try { wm.addView(engineView, lp); } catch (Exception ignored) {}
            if (pos != null) requestAnalysis(null);
        } else if (!need && engine.isRunning()) {
            stopEngine();
        }
    }

    private void stopEngine() {
        try { if (engineView != null) wm.removeView(engineView); } catch (Exception ignored) {}
        engineView = null;
        if (engine != null) engine.stop();
        analyzedGen = -1;
    }

    // ======================================================================
    // UI
    private void setStatus(String s) { if (status != null) status.setText(s); }

    private int px(int v) { return (int) (v * dp); }

    private void buildOverlays() {
        // rating badge layer (touch-through, full screen)
        badge = new BadgeView(this);
        WindowManager.LayoutParams bl = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bl.gravity = Gravity.TOP | Gravity.START;
        bl.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(badge, bl);

        // floating bubble
        bubble = new TextView(this);
        bubble.setText("\u265E");
        bubble.setTextSize(22);
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xFF769656);
        bubble.setBackground(bg);
        bubbleLp = new WindowManager.LayoutParams(px(44), px(44),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = sp.getInt("bx", 0);
        bubbleLp.y = sp.getInt("by", px(110));
        bubbleX = bubbleLp.x;
        bubbleY = bubbleLp.y;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = bubbleLp.x; sy = bubbleLp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > 12 || Math.abs(e.getRawY() - dy) > 12) moved = true;
                        if (moved) {
                            bubbleLp.x = sx + (int) (e.getRawX() - dx);
                            bubbleLp.y = sy + (int) (e.getRawY() - dy);
                            bubbleX = bubbleLp.x; bubbleY = bubbleLp.y;
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) sp.edit().putInt("bx", bubbleLp.x).putInt("by", bubbleLp.y).apply();
                        else togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);

        buildPanel();
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(px(16), px(14), px(16), px(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF262522);
        bg.setCornerRadius(px(14));
        panel.setBackground(bg);

        TextView title = label("Chess Assistant", 17, true);
        panel.addView(title);

        final TextView dl = label("Stockfish Deep: " + depth, 14, false);
        panel.addView(dl);
        SeekBar sd = new SeekBar(this);
        sd.setMax(14);
        sd.setProgress(depth - 1);
        sd.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                depth = p + 1;
                dl.setText("Stockfish Deep: " + depth);
                sp.edit().putInt("depth", depth).apply();
            }
        });
        panel.addView(sd);

        final Switch sa = new Switch(this);
        sa.setText("Auto move");
        sa.setTextColor(Color.WHITE);
        sa.setChecked(autoMove);
        sa.setOnCheckedChangeListener((b, on) -> {
            autoMove = on;
            sp.edit().putBoolean("auto", on).apply();
            syncEngine();
        });
        panel.addView(sa);

        final TextView ll = label("Auto move delay: " + delaySec + " s", 14, false);
        panel.addView(ll);
        SeekBar sl = new SeekBar(this);
        sl.setMax(19);
        sl.setProgress(delaySec - 1);
        sl.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override void changed(int p) {
                delaySec = p + 1;
                ll.setText("Auto move delay: " + delaySec + " s");
                sp.edit().putInt("delay", delaySec).apply();
            }
        });
        panel.addView(sl);

        final Switch sr = new Switch(this);
        sr.setText("Move rating");
        sr.setTextColor(Color.WHITE);
        sr.setChecked(rating);
        sr.setOnCheckedChangeListener((b, on) -> {
            rating = on;
            sp.edit().putBoolean("rating", on).apply();
            if (!on) { badge.clear(); badgeMask = null; }
            syncEngine();
        });
        panel.addView(sr);

        status = label("", 12, false);
        status.setTextColor(0xFFAAAAAA);
        status.setPadding(0, px(10), 0, 0);
        panel.addView(status);

        panelLp = new WindowManager.LayoutParams(px(300), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelLp.y = px(70);
    }

    private TextView label(String t, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(size);
        v.setTextColor(Color.WHITE);
        v.setPadding(0, px(6), 0, 0);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private void togglePanel() {
        try {
            if (panelOpen) { wm.removeView(panel); panelOpen = false; }
            else { wm.addView(panel, panelLp); panelOpen = true; }
        } catch (Exception ignored) {}
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        abstract void changed(int p);
        @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) changed(p); }
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }

    /** Draws one rating badge on top of the game. Touch-through. */
    static final class BadgeView extends View {
        private float cx, cy, r;
        private String text;
        private int color;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        BadgeView(Context c) { super(c); }

        void show(float x, float y, float rad, String t, int col) {
            cx = x; cy = y; r = rad; text = t; color = col;
            invalidate();
        }

        void clear() {
            if (text != null) { text = null; invalidate(); }
        }

        @Override protected void onDraw(Canvas c) {
            if (text == null) return;
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(r * 0.12f);
            p.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(r * (text.length() > 1 ? 1.0f : 1.25f));
            c.drawText(text, cx, cy - (p.descent() + p.ascent()) / 2f, p);
        }
    }
}
