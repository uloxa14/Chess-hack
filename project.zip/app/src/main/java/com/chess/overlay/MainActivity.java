package com.chess.overlay;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private boolean serviceOn() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(getPackageName() + "/");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (serviceOn()) showControls(); else showSetup();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    /** Accessibility is on: only two buttons. */
    private void showControls() {
        final SharedPreferences sp = getSharedPreferences("prefs", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(32), dp(32), dp(32), dp(32));

        final TextView state = new TextView(this);
        state.setTextSize(15);
        state.setGravity(Gravity.CENTER);
        state.setPadding(0, 0, 0, dp(16));
        root.addView(state);

        Button on = new Button(this);
        on.setText("Enable Menu");
        on.setOnClickListener(v -> { sp.edit().putBoolean("menu", true).apply(); refresh(state, sp); });
        root.addView(on, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));

        Button off = new Button(this);
        off.setText("Disable Menu");
        off.setOnClickListener(v -> { sp.edit().putBoolean("menu", false).apply(); refresh(state, sp); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.topMargin = dp(12);
        root.addView(off, lp);

        refresh(state, sp);
        setContentView(root);
    }

    private void refresh(TextView state, SharedPreferences sp) {
        boolean m = sp.getBoolean("menu", true);
        state.setText(m ? "Menu: ON" : "Menu: OFF");
        state.setTextColor(m ? 0xFF2E7D32 : 0xFFC62828);
    }

    /** Accessibility is off: explain and open the settings. */
    private void showSetup() {
        int pad = dp(22);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Chess Assistant");
        title.setTextSize(22);
        root.addView(title);

        TextView st = new TextView(this);
        st.setTextSize(16);
        st.setPadding(0, pad / 2, 0, pad / 2);
        st.setText("Accessibility service: OFF");
        st.setTextColor(0xFFC62828);
        root.addView(st);

        TextView help = new TextView(this);
        help.setTextSize(14);
        help.setText("Tap \"Open accessibility settings\", find Chess Assistant and turn it on.\n"
                + "Android 13+: if the switch is greyed out, tap \"Open app info\", open the \u22EE menu and choose \"Allow restricted settings\", then try again.");
        root.addView(help);

        Button a = new Button(this);
        a.setText("Open accessibility settings");
        a.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(a);

        Button i = new Button(this);
        i.setText("Open app info");
        i.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        root.addView(i);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }
}
