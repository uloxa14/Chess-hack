package com.chess.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView text = new TextView(this);
        text.setText("Для работы кружка нужно разрешение «Поверх других приложений».");
        text.setTextSize(16);
        text.setGravity(Gravity.CENTER);
        root.addView(text);

        Button btn = new Button(this);
        btn.setText("Выдать разрешение");
        btn.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        root.addView(btn);

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!Settings.canDrawOverlays(this)) return;

        // Один раз просим исключить приложение из ограничений батареи — иначе система может убивать кружок
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            android.content.SharedPreferences sp = getSharedPreferences("prefs", MODE_PRIVATE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())
                    && !sp.getBoolean("batteryAsked", false)) {
                sp.edit().putBoolean("batteryAsked", true).apply();
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
        } catch (Exception ignored) {}

        final java.io.File crash = new java.io.File(getFilesDir(), "crash.txt");
        if (crash.exists()) {
            // Прошлый запуск упал — показываем причину вместо мгновенного запуска
            String log;
            try {
                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(crash));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null && sb.length() < 3000) sb.append(line).append('\n');
                br.close();
                log = sb.toString();
            } catch (Exception e) {
                log = "Не удалось прочитать лог";
            }
            root.removeAllViews();
            TextView t = new TextView(this);
            t.setText("Прошлый запуск упал с ошибкой:\n\n" + log);
            t.setTextSize(11);
            t.setTextIsSelectable(true);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(t);
            root.addView(sv, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            Button go = new Button(this);
            go.setText("Запустить кружок");
            go.setOnClickListener(v -> {
                crash.delete();
                startForegroundService(new Intent(this, OverlayService.class));
                finish();
            });
            root.addView(go);
            return;
        }

        startForegroundService(new Intent(this, OverlayService.class));
        finish();
    }
}
