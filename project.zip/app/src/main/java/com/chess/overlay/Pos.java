package com.chess.overlay;

/** Tracks the game from board occupancy only (empty / white / black per square). Index = rank*8+file, a1 = 0. */
final class Pos {
    char[] b = new char[64];
    boolean white = true;
    boolean cwK = true, cwQ = true, cbK = true, cbQ = true;
    int ep = -1;
    int full = 1;
    int plies = 0;

    static final class Mv {
        int from, to;
        boolean castle;
        String uci() { return sq(from) + sq(to); }
    }

    Mv last;

    static Pos start() {
        Pos p = new Pos();
        String back = "RNBQKBNR";
        for (int f = 0; f < 8; f++) {
            p.b[f] = back.charAt(f);
            p.b[8 + f] = 'P';
            p.b[48 + f] = 'p';
            p.b[56 + f] = Character.toLowerCase(back.charAt(f));
            for (int r = 2; r < 6; r++) p.b[r * 8 + f] = '.';
        }
        return p;
    }

    static String sq(int i) { return "" + (char) ('a' + i % 8) + (char) ('1' + i / 8); }
    static int idx(String s, int o) { return (s.charAt(o + 1) - '1') * 8 + (s.charAt(o) - 'a'); }

    Pos copy() {
        Pos p = new Pos();
        p.b = b.clone(); p.white = white; p.cwK = cwK; p.cwQ = cwQ; p.cbK = cbK; p.cbQ = cbQ;
        p.ep = ep; p.full = full; p.plies = plies;
        return p;
    }

    int[] occ() {
        int[] o = new int[64];
        for (int i = 0; i < 64; i++) o[i] = b[i] == '.' ? 0 : (Character.isUpperCase(b[i]) ? 1 : 2);
        return o;
    }

    String fen() {
        StringBuilder s = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int e = 0;
            for (int f = 0; f < 8; f++) {
                char c = b[r * 8 + f];
                if (c == '.') e++;
                else { if (e > 0) { s.append(e); e = 0; } s.append(c); }
            }
            if (e > 0) s.append(e);
            if (r > 0) s.append('/');
        }
        s.append(white ? " w " : " b ");
        String c = (cwK ? "K" : "") + (cwQ ? "Q" : "") + (cbK ? "k" : "") + (cbQ ? "q" : "");
        s.append(c.isEmpty() ? "-" : c).append(' ');
        s.append(ep < 0 ? "-" : sq(ep)).append(" 0 ").append(full);
        return s.toString();
    }

    /** 0 = nothing changed, 1 = one move recognised and applied, 2 = change cannot be explained by one move. */
    int observe(int[] o) {
        int[] cur = occ();
        boolean same = true;
        for (int i = 0; i < 64; i++) if (cur[i] != o[i]) { same = false; break; }
        if (same) return 0;
        int mover = white ? 1 : 2, opp = 3 - mover;
        int[] A = new int[64], B = new int[64];
        int na = 0, nb = 0;
        for (int i = 0; i < 64; i++) {
            if (o[i] == opp && cur[i] != opp) return 2; // opponent piece appeared
            if (cur[i] == mover && o[i] != mover) A[na++] = i;
            if (o[i] == mover && cur[i] != mover) B[nb++] = i;
        }
        Pos n = copy();
        Mv m = new Mv();
        if (na == 2 && nb == 2) {
            int k = white ? 4 : 60;
            char king = white ? 'K' : 'k', rook = white ? 'R' : 'r';
            if (b[k] != king || !has(A, na, k)) return 2;
            if (has(B, nb, k + 2) && has(A, na, k + 3)) {
                n.b[k + 2] = king; n.b[k + 1] = rook; n.b[k] = '.'; n.b[k + 3] = '.';
            } else if (has(B, nb, k - 2) && has(A, na, k - 4)) {
                n.b[k - 2] = king; n.b[k - 1] = rook; n.b[k] = '.'; n.b[k - 4] = '.';
            } else return 2;
            m.from = k; m.to = has(B, nb, k + 2) ? k + 2 : k - 2; m.castle = true;
            if (white) { n.cwK = false; n.cwQ = false; } else { n.cbK = false; n.cbQ = false; }
            n.ep = -1;
        } else if (na == 1 && nb == 1) {
            int from = A[0], to = B[0];
            char p = b[from];
            m.from = from; m.to = to;
            boolean pawn = p == 'P' || p == 'p';
            if (pawn && from % 8 != to % 8 && b[to] == '.') n.b[(from / 8) * 8 + to % 8] = '.'; // en passant
            n.b[to] = p; n.b[from] = '.';
            if (pawn && (to >= 56 || to <= 7)) n.b[to] = white ? 'Q' : 'q';
            n.ep = (pawn && Math.abs(to - from) == 16) ? (from + to) / 2 : -1;
            if (from == 4 || to == 4) { n.cwK = false; n.cwQ = false; }
            if (from == 60 || to == 60) { n.cbK = false; n.cbQ = false; }
            if (from == 0 || to == 0) n.cwQ = false;
            if (from == 7 || to == 7) n.cwK = false;
            if (from == 56 || to == 56) n.cbQ = false;
            if (from == 63 || to == 63) n.cbK = false;
        } else return 2;
        int[] chk = n.occ();
        for (int i = 0; i < 64; i++) if (chk[i] != o[i]) return 2;
        if (!white) n.full++;
        n.white = !white;
        n.plies = plies + 1;
        b = n.b; white = n.white; cwK = n.cwK; cwQ = n.cwQ; cbK = n.cbK; cbQ = n.cbQ;
        ep = n.ep; full = n.full; plies = n.plies; last = m;
        return 1;
    }

    // ---- catching up on several plies ----
    private int nodes;

    private static final int[] KN = {17, 15, 10, 6, -6, -10, -15, -17};

    /** Pseudo-legal moves of the side to move, encoded from*64+to. */
    int genMoves(int[] out) {
        int n = 0;
        for (int i = 0; i < 64; i++) {
            char c = b[i];
            if (c == '.' || Character.isUpperCase(c) != white) continue;
            int f = i % 8, r = i / 8;
            char t = Character.toLowerCase(c);
            if (t == 'p') {
                int dir = white ? 1 : -1, r1 = r + dir;
                if (r1 < 0 || r1 > 7) continue;
                if (b[r1 * 8 + f] == '.') {
                    out[n++] = i * 64 + r1 * 8 + f;
                    int sr = white ? 1 : 6;
                    if (r == sr && b[(r + 2 * dir) * 8 + f] == '.') out[n++] = i * 64 + (r + 2 * dir) * 8 + f;
                }
                for (int df = -1; df <= 1; df += 2) {
                    int nf = f + df;
                    if (nf < 0 || nf > 7) continue;
                    int to = r1 * 8 + nf;
                    char tc = b[to];
                    if (tc != '.' ? Character.isUpperCase(tc) != white : to == ep) out[n++] = i * 64 + to;
                }
            } else if (t == 'n') {
                for (int d : KN) {
                    int to = i + d;
                    if (to < 0 || to > 63) continue;
                    int tf = to % 8, tr = to / 8;
                    if (Math.abs(tf - f) + Math.abs(tr - r) != 3) continue;
                    char tc = b[to];
                    if (tc == '.' || Character.isUpperCase(tc) != white) out[n++] = i * 64 + to;
                }
            } else if (t == 'k') {
                for (int dr = -1; dr <= 1; dr++)
                    for (int df = -1; df <= 1; df++) {
                        if (dr == 0 && df == 0) continue;
                        int nr = r + dr, nf = f + df;
                        if (nr < 0 || nr > 7 || nf < 0 || nf > 7) continue;
                        int to = nr * 8 + nf;
                        char tc = b[to];
                        if (tc == '.' || Character.isUpperCase(tc) != white) out[n++] = i * 64 + to;
                    }
                if (white && i == 4) {
                    if (cwK && b[5] == '.' && b[6] == '.' && b[7] == 'R') out[n++] = i * 64 + 6;
                    if (cwQ && b[3] == '.' && b[2] == '.' && b[1] == '.' && b[0] == 'R') out[n++] = i * 64 + 2;
                } else if (!white && i == 60) {
                    if (cbK && b[61] == '.' && b[62] == '.' && b[63] == 'r') out[n++] = i * 64 + 62;
                    if (cbQ && b[59] == '.' && b[58] == '.' && b[57] == '.' && b[56] == 'r') out[n++] = i * 64 + 58;
                }
            } else {
                boolean diag = t == 'b' || t == 'q', orth = t == 'r' || t == 'q';
                for (int dr = -1; dr <= 1; dr++)
                    for (int df = -1; df <= 1; df++) {
                        if (dr == 0 && df == 0) continue;
                        boolean isDiag = dr != 0 && df != 0;
                        if (isDiag ? !diag : !orth) continue;
                        int nr = r + dr, nf = f + df;
                        while (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                            int to = nr * 8 + nf;
                            char tc = b[to];
                            if (tc == '.') out[n++] = i * 64 + to;
                            else { if (Character.isUpperCase(tc) != white) out[n++] = i * 64 + to; break; }
                            nr += dr; nf += df;
                        }
                    }
            }
        }
        return n;
    }

    /** Plays a pseudo-legal move and returns the new position. */
    Pos play(int from, int to) {
        Pos n = copy();
        char p = b[from];
        boolean pawn = p == 'P' || p == 'p', king = p == 'K' || p == 'k';
        Mv m = new Mv();
        m.from = from; m.to = to;
        if (pawn && from % 8 != to % 8 && b[to] == '.') n.b[(from / 8) * 8 + to % 8] = '.';
        n.b[to] = p; n.b[from] = '.';
        if (pawn && (to >= 56 || to <= 7)) n.b[to] = white ? 'Q' : 'q';
        if (king && Math.abs(to - from) == 2) {
            char rook = white ? 'R' : 'r';
            if (to > from) { n.b[from + 1] = rook; n.b[from + 3] = '.'; }
            else { n.b[from - 1] = rook; n.b[from - 4] = '.'; }
            m.castle = true;
        }
        n.ep = (pawn && Math.abs(to - from) == 16) ? (from + to) / 2 : -1;
        if (from == 4 || to == 4) { n.cwK = false; n.cwQ = false; }
        if (from == 60 || to == 60) { n.cbK = false; n.cbQ = false; }
        if (from == 0 || to == 0) n.cwQ = false;
        if (from == 7 || to == 7) n.cwK = false;
        if (from == 56 || to == 56) n.cbQ = false;
        if (from == 63 || to == 63) n.cbK = false;
        if (!white) n.full++;
        n.white = !white;
        n.plies = plies + 1;
        n.last = m;
        return n;
    }

    private int mismatch(int[] o) {
        int d = 0;
        for (int i = 0; i < 64; i++) {
            char c = b[i];
            int cur = c == '.' ? 0 : (Character.isUpperCase(c) ? 1 : 2);
            if (cur != o[i]) d++;
        }
        return d;
    }

    private Pos dfs(int[] o, int depth) {
        int mm = mismatch(o);
        if (depth == 0) return mm == 0 ? this : null;
        if (mm > 2 * depth + 2 || --nodes < 0) return null;
        int[] mv = new int[256];
        int n = genMoves(mv);
        for (int i = 0; i < n; i++) {
            Pos r = play(mv[i] / 64, mv[i] % 64).dfsFrom(this, o, depth - 1);
            if (r != null) return r;
        }
        return null;
    }

    private Pos dfsFrom(Pos parent, int[] o, int depth) {
        nodes = parent.nodes;
        Pos r = dfs(o, depth);
        parent.nodes = nodes;
        return r;
    }

    /**
     * Finds a short sequence of moves (up to maxPlies) from this position that leads to the observed occupancy.
     * Returns the resulting position (this one if nothing changed) or null.
     */
    Pos catchUp(int[] o, int maxPlies) {
        if (mismatch(o) == 0) return this;
        for (int d = 1; d <= maxPlies; d++) {
            nodes = 40000;
            Pos r = dfs(o, d);
            if (r != null) return r;
            if (nodes < 0) break;
        }
        return null;
    }

    private static boolean has(int[] a, int n, int v) {
        for (int i = 0; i < n; i++) if (a[i] == v) return true;
        return false;
    }

    /** screenOcc is indexed r*8+c as seen on screen. Returns 0 = not a start position, 1 = white at bottom, 2 = black at bottom. */
    static int startOrientation(int[] s) {
        int top = s[0], bot = s[56];
        if (top <= 0 || bot <= 0 || top == bot) return 0;
        for (int i = 0; i < 64; i++) {
            int r = i / 8;
            int want = (r <= 1) ? top : (r >= 6 ? bot : 0);
            if (s[i] != want) return 0;
        }
        return bot == 1 ? 1 : 2;
    }

    static int[] toBoard(int[] scr, boolean flipped) {
        int[] o = new int[64];
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                int file = flipped ? 7 - c : c, rank = flipped ? r : 7 - r;
                o[rank * 8 + file] = scr[r * 8 + c];
            }
        return o;
    }

    /** board index -> screen index (r*8+c) */
    static int toScreen(int bi, boolean flipped) {
        int file = bi % 8, rank = bi / 8;
        int c = flipped ? 7 - file : file, r = flipped ? rank : 7 - rank;
        return r * 8 + c;
    }
}
