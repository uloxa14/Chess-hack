package com.chess.overlay;

/** Finds the (green) chess.com board in a screenshot and classifies every square: 0 empty, 1 white piece, 2 black piece, -1 unknown. */
final class Vision {
    float x0, y0, s;
    boolean ok;

    private static boolean dark(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return Math.abs(r - 118) < 18 && Math.abs(g - 150) < 18 && Math.abs(b - 86) < 18;
    }

    boolean detect(int[] px, int w, int h) {
        ok = false;
        int step = 3;
        float[] rf = new float[h];
        for (int y = 0; y < h; y += 1) {
            int c = 0;
            for (int x = 0; x < w; x += step) if (dark(px[y * w + x])) c++;
            rf[y] = c / (float) (w / step);
        }
        // longest run of rows that look like board rows (gaps up to 3 rows allowed)
        int bestS = -1, bestE = -1, curS = -1, gap = 0;
        for (int y = 0; y < h; y++) {
            if (rf[y] > 0.12f) {
                if (curS < 0) curS = y;
                gap = 0;
                if (bestS < 0 || y - curS > bestE - bestS) { bestS = curS; bestE = y; }
            } else if (curS >= 0 && ++gap > 3) { curS = -1; gap = 0; }
        }
        if (bestS < 0 || bestE - bestS < w / 3) return false;
        int top = bestS, bottom = bestE;
        int left = -1, right = -1;
        for (int x = 0; x < w; x++) {
            int c = 0;
            for (int y = top; y <= bottom; y += step) if (dark(px[y * w + x])) c++;
            if (c / (float) ((bottom - top) / step + 1) > 0.12f) { if (left < 0) left = x; right = x; }
        }
        if (left < 0) return false;
        float bw = right - left + 1, bh = bottom - top + 1;
        if (Math.abs(bw - bh) > 0.04f * bw || bw < w * 0.5f) return false;
        s = (bw + bh) / 16f;
        x0 = left; y0 = top;
        ok = true;
        return true;
    }

    /** px holds the region that starts at screen (offX, offY) and has the given row stride. masks = triples (cx, cy, r) in screen px to ignore. */
    int[] classify(int[] px, int stride, int offX, int offY, float[] masks, ArrowShape arrow) {
        int[] res = new int[64];
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                int xs = Math.round(x0 + c * s + 0.18f * s), xe = Math.round(x0 + c * s + 0.82f * s);
                int ys = Math.round(y0 + r * s + 0.18f * s), ye = Math.round(y0 + r * s + 0.82f * s);
                int total = 0, valid = 0, dk = 0;
                for (int y = ys; y < ye; y += 2)
                    for (int x = xs; x < xe; x += 2) {
                        total++;
                        if (masked(masks, x, y)) continue;
                        int p = px[(y - offY) * stride + (x - offX)];
                        if (arrow != null) {
                            int cv = arrow.cover(x + 0.5f, y + 0.5f);
                            if (cv == 2) continue;                 // anti-aliased edge of the arrow
                            if (cv == 1) p = arrow.unblend(p);     // remove the arrow tint
                        }
                        int lum = (299 * ((p >> 16) & 255) + 587 * ((p >> 8) & 255) + 114 * (p & 255)) / 1000;
                        valid++;
                        if (lum < 110) dk++;
                    }
                int v;
                if (valid < total * 0.4f) v = -1;
                else {
                    float f = dk / (float) valid;
                    v = f < 0.035f ? 0 : (f >= 0.25f ? 2 : 1);
                }
                res[r * 8 + c] = v;
            }
        return res;
    }

    private static boolean boardLike(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        if (dark(p)) return true;
        if (Math.abs(r - 238) < 22 && Math.abs(g - 238) < 22 && Math.abs(b - 210) < 26) return true;
        return r > 150 && g > 150 && b < 150 && r - b > 50 && g - b > 50; // last-move highlights
    }

    /** How many of the 64 squares show board colours at their corner. Low = the board is not where we think (or is covered). */
    int boardScore(int[] px, int stride, int offX, int offY) {
        int ok = 0, rows = px.length / stride;
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                int x = Math.round(x0 + c * s + 0.07f * s) - offX, y = Math.round(y0 + r * s + 0.07f * s) - offY;
                if (x < 0 || y < 0 || x >= stride || y >= rows) continue;
                if (boardLike(px[y * stride + x])) ok++;
            }
        return ok;
    }

    private static boolean masked(float[] m, int x, int y) {
        if (m == null) return false;
        for (int i = 0; i + 2 < m.length; i += 3) {
            float dx = x - m[i], dy = y - m[i + 1];
            if (dx * dx + dy * dy <= m[i + 2] * m[i + 2]) return true;
        }
        return false;
    }
}
