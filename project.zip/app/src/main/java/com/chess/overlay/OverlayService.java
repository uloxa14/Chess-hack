package com.chess.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;

public class OverlayService extends Service {

    private static final String CHANNEL_ID = "overlay";
    private static final String ACTION_STOP = "com.chess.overlay.STOP";

    private WindowManager wm;
    private View bubble;
    private FrameLayout panel;
    private WebView webView;
    private Context themedCtx;
    private WindowManager.LayoutParams bubbleLp;
    private WindowManager.LayoutParams panelLp;
    private boolean bubbleAttached = false;
    private boolean panelAttached = false;
    private float density;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;

        startAsForeground();
        buildBubble();
        buildPanel();
        showBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private int dp(int v) {
        return (int) (v * density + 0.5f);
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, "Плавающий кружок", NotificationManager.IMPORTANCE_LOW));

        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Шахматы")
                .setContentText("Кружок активен")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Выключить", stopPi).build())
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- Кружок ----------

    private void buildBubble() {
        bubble = new View(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.WHITE);
        bg.setStroke(dp(1), 0xFFBBBBBB);
        bubble.setBackground(bg);
        bubble.setElevation(dp(6));

        int size = dp(56);
        bubbleLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = dp(16);
        bubbleLp.y = dp(200);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = startX + (int) dx;
                            bubbleLp.y = startY + (int) dy;
                            if (bubbleAttached) wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) showPanel();
                        return true;
                }
                return false;
            }
        });
    }

    private void showBubble() {
        if (!bubbleAttached) {
            wm.addView(bubble, bubbleLp);
            bubbleAttached = true;
        }
    }

    private void hideBubble() {
        if (bubbleAttached) {
            wm.removeView(bubble);
            bubbleAttached = false;
        }
    }

    // ---------- Мини-окно с HTML ----------

    private void buildPanel() {
        Context themed = new ContextThemeWrapper(this, android.R.style.Theme_Material_Light);

        themedCtx = themed;
        webView = createWebView();

        panel = new FrameLayout(themed);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF161512);
        bg.setCornerRadius(dp(16));
        panel.setBackground(bg);
        panel.setClipToOutline(true);
        panel.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(16));
            }
        });
        panel.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Крестик справа сверху
        TextView close = new TextView(themed);
        close.setText("✕");
        close.setTextColor(Color.BLACK);
        close.setTextSize(16);
        close.setGravity(Gravity.CENTER);
        GradientDrawable cbg = new GradientDrawable();
        cbg.setShape(GradientDrawable.OVAL);
        cbg.setColor(0xDDFFFFFF);
        close.setBackground(cbg);
        close.setElevation(dp(10));
        close.setOnClickListener(v -> hidePanel());
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(dp(36), dp(36));
        clp.gravity = Gravity.TOP | Gravity.END;
        clp.topMargin = dp(8);
        clp.rightMargin = dp(8);
        panel.addView(close, clp);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = (int) (dm.widthPixels * 0.94f);
        int h = (int) (dm.heightPixels * 0.78f);
        panelLp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.CENTER;
    }

    private WebView createWebView() {
        WebView wv = new WebView(themedCtx);
        WebSettings st = wv.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        wv.setBackgroundColor(0xFF161512);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            // Если процесс WebView убит системой, не роняем приложение, а пересоздаём страницу
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                if (panel != null && view == webView) {
                    panel.removeView(view);
                    view.destroy();
                    webView = createWebView();
                    panel.addView(webView, 0, new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT));
                }
                return true;
            }
        });
        wv.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        return wv;
    }

    private void showPanel() {
        hideBubble();
        if (!panelAttached) {
            wm.addView(panel, panelLp);
            panelAttached = true;
        }
    }

    private void hidePanel() {
        if (panelAttached) {
            wm.removeView(panel);
            panelAttached = false;
        }
        showBubble();
    }

    // При нехватке памяти просим страницу сбросить кэш и перезапустить Stockfish
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_LOW && webView != null) {
            try {
                webView.evaluateJavascript("window.__trimMemory && window.__trimMemory()", null);
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try { if (bubbleAttached) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (panelAttached) wm.removeView(panel); } catch (Exception ignored) {}
        bubbleAttached = false;
        panelAttached = false;
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
    }
}
