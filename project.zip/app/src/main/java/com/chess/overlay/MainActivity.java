package com.chess.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView text = new TextView(this);
        text.setText("Для работы кружка нужно разрешение «Поверх других приложений».");
        text.setTextSize(16);
        text.setGravity(Gravity.CENTER);
        root.addView(text);

        Button btn = new Button(this);
        btn.setText("Выдать разрешение");
        btn.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        root.addView(btn);

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!Settings.canDrawOverlays(this)) return;

        // Один раз просим исключить приложение из ограничений батареи — иначе система может убивать кружок
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            android.content.SharedPreferences sp = getSharedPreferences("prefs", MODE_PRIVATE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())
                    && !sp.getBoolean("batteryAsked", false)) {
                sp.edit().putBoolean("batteryAsked", true).apply();
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
        } catch (Exception ignored) {}

        // Собираем отчёт: ошибка из лога + причины, по которым система убивала процесс (Android 11+)
        StringBuilder rep = new StringBuilder();
        final java.io.File crash = new java.io.File(getFilesDir(), "crash.txt");
        if (crash.exists()) {
            try {
                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(crash));
                String line;
                int n = 0;
                rep.append("ОШИБКА В КОДЕ:\n");
                while ((line = br.readLine()) != null && n++ < 25) rep.append(line).append('\n');
                br.close();
            } catch (Exception e) {
                rep.append("Не удалось прочитать лог ошибки\n");
            }
            rep.append('\n');
        }

        long newestSeen = 0;
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                android.content.SharedPreferences sp = getSharedPreferences("prefs", MODE_PRIVATE);
                long seen = sp.getLong("exitSeen", 0);
                android.app.ActivityManager am =
                        (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
                java.util.List<android.app.ApplicationExitInfo> list =
                        am.getHistoricalProcessExitReasons(getPackageName(), 0, 5);
                java.text.SimpleDateFormat fmt =
                        new java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.getDefault());
                boolean any = false;
                for (android.app.ApplicationExitInfo e : list) {
                    if (e.getTimestamp() <= seen) continue;
                    newestSeen = Math.max(newestSeen, e.getTimestamp());
                    if (!any) { rep.append("ПРИЧИНЫ, ПО КОТОРЫМ СИСТЕМА ЗАВЕРШАЛА ПРИЛОЖЕНИЕ:\n"); any = true; }
                    rep.append("• ").append(fmt.format(new java.util.Date(e.getTimestamp())))
                       .append(" — ").append(exitReasonName(e.getReason()))
                       .append(", процесс: ").append(e.getProcessName())
                       .append(", память(RSS): ").append(e.getRss() / 1024).append(" МБ")
                       .append("\n  ").append(e.getDescription() == null ? "" : e.getDescription())
                       .append('\n');
                }
            } catch (Exception ignored) {}
        }

        if (rep.length() > 0) {
            final long markSeen = newestSeen;
            root.removeAllViews();
            TextView t = new TextView(this);
            t.setText(rep.toString());
            t.setTextSize(11);
            t.setTextIsSelectable(true);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(t);
            root.addView(sv, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            Button go = new Button(this);
            go.setText("Запустить кружок");
            go.setOnClickListener(v -> {
                crash.delete();
                if (markSeen > 0) {
                    getSharedPreferences("prefs", MODE_PRIVATE).edit().putLong("exitSeen", markSeen).apply();
                }
                startForegroundService(new Intent(this, OverlayService.class));
                finish();
            });
            root.addView(go);
            return;
        }

        startForegroundService(new Intent(this, OverlayService.class));
        finish();
    }

    private static String exitReasonName(int r) {
        switch (r) {
            case 1: return "EXIT_SELF (приложение само завершилось)";
            case 2: return "SIGNALED (убит сигналом)";
            case 3: return "LOW_MEMORY (системе не хватило памяти)";
            case 4: return "CRASH (падение Java-кода)";
            case 5: return "CRASH_NATIVE (падение нативного кода)";
            case 6: return "ANR (приложение зависло)";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE (изменено разрешение)";
            case 9: return "EXCESSIVE_RESOURCE_USAGE (слишком много ресурсов)";
            case 10: return "USER_REQUESTED (завершено пользователем)";
            case 11: return "USER_STOPPED (остановлено пользователем)";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER (другая причина)";
            case 14: return "FREEZER (заморожено системой)";
            case 15: return "PACKAGE_STATE_CHANGE";
            case 16: return "PACKAGE_UPDATED";
            default: return "код " + r;
        }
    }
}
