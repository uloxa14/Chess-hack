package com.chess.overlay;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.ContextThemeWrapper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Runs the bundled Stockfish (wasm) inside a hidden WebView. All public methods must be called on the main thread. */
final class Engine {

    interface Cb { void done(int cp, String best); }

    private static final String PAGE = "<html><body><script>"
            + "var w=null,cur=null;"
            + "function boot(){"
            + " var g=Android.glue(),b=Android.wasm();"
            + " g=g.replace('{locateFile:','{wasmBinary:__W,locateFile:');"
            + " var src='var __W=(function(b){var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u;})(\"'+b+'\");\\n'+g;"
            + " w=new Worker(URL.createObjectURL(new Blob([src],{type:'application/javascript'})));"
            + " w.onmessage=function(e){var l=String(e.data);"
            + "  if(l.indexOf('info')===0){if(cur&&l.indexOf(' depth ')>0&&l.indexOf('bound')<0){var m=/ score (cp|mate) (-?\\d+)/.exec(l);if(m){cur.t=m[1];cur.v=parseInt(m[2]);}}}"
            + "  else if(l.indexOf('bestmove')===0){var p=l.split(' ');if(cur){var c=cur;cur=null;Android.result(c.id,c.t==='mate'?1:0,c.v||0,p[1]||'');}}"
            + "  else if(l.indexOf('readyok')===0){Android.ready();}};"
            + " w.postMessage('uci');w.postMessage('isready');}"
            + "function go(id,fen,d,mt){cur={id:id,t:'cp',v:0};w.postMessage('position fen '+fen);w.postMessage('go depth '+d+' movetime '+mt);}"
            + "boot();"
            + "</script></body></html>";

    private static final class Req { int id; String fen; int depth; Cb cb; }

    private final Context ctx;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView wv;
    private boolean ready, busy;
    private int nextId, activeId, latestId;
    private Cb activeCb;
    private Req pending;

    Engine(Context c) { ctx = c.getApplicationContext(); }

    WebView start() {
        wv = new WebView(new ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault));
        WebSettings st = wv.getSettings();
        st.setJavaScriptEnabled(true);
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadDataWithBaseURL("https://engine.local/", PAGE, "text/html", "utf-8", null);
        return wv;
    }

    void stop() {
        ready = false; busy = false; pending = null; activeCb = null;
        if (wv != null) { wv.destroy(); wv = null; }
    }

    boolean isRunning() { return wv != null; }

    /** Analyses a position. The callback gets the score in centipawns (side to move, clipped to +-1000) and the best move in UCI. Older queued requests are dropped. */
    void request(String fen, int depth, Cb cb) {
        if (wv == null) return;
        Req r = new Req();
        r.id = ++nextId; r.fen = fen; r.depth = depth; r.cb = cb;
        latestId = r.id;
        pending = r;
        pump();
    }

    private void pump() {
        if (wv == null || !ready || busy || pending == null) return;
        Req r = pending;
        pending = null;
        busy = true;
        activeId = r.id;
        activeCb = r.cb;
        int movetime = Math.min(12000, 1500 + 600 * r.depth);
        wv.evaluateJavascript("go(" + r.id + ",'" + r.fen + "'," + r.depth + "," + movetime + ")", null);
    }

    private String asset(String name, boolean b64) {
        try (InputStream in = ctx.getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            byte[] all = bo.toByteArray();
            return b64 ? Base64.encodeToString(all, Base64.NO_WRAP) : new String(all, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private final class Bridge {
        @JavascriptInterface public String glue() { return asset("stockfish_wasm.js", false); }
        @JavascriptInterface public String wasm() { return asset("stockfish.wasm", true); }

        @JavascriptInterface public void ready() {
            ui.post(() -> { ready = true; pump(); });
        }

        @JavascriptInterface public void result(final int id, final int mate, final int v, final String best) {
            ui.post(() -> {
                busy = false;
                Cb cb = activeCb;
                activeCb = null;
                if (id == activeId && id == latestId && cb != null) {
                    int cp = mate == 1 ? (v > 0 ? 1000 : -1000) : Math.max(-1000, Math.min(1000, v));
                    boolean none = best == null || best.length() < 4 || best.startsWith("(");
                    cb.done(cp, none ? null : best);
                }
                pump();
            });
        }
    }
}
